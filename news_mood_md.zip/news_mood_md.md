
# ANALYSES
####1.The timestamp has no effect on the tweets sentiment analysis. Meaning no matter how current the tweet, the time is independent of the content (ie, more positive information in the day and more negative information in the evening)
####2.There have not been many tweets with a compound score of 1.0 meaning that there are no recent news tweets with enough positive sentiment analysis to increase the compound score, which means that the news has been generally negative
####3. There is a lot of overlap between all news feeds at 0.0, implying that there is enough pos and neg analysis to zero out the compound....so perhaps we can infer that the news has an equal balance of pos and neg content. 


```python

#Dependencies 
import tweepy
import json
import matplotlib.pyplot as plt
import seaborn as sns
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()
import pandas as pd
import numpy as np
import seaborn as sns
```


```python
#Twitter API Keys
consumer_key = 'wOuObtxETjIrRImGH7PoWBDk8'
consumer_secret = 'ErKd6eKDvuzijoMaeV3mP1Lp9ACKwzL2MlLCCJHuebahT8zsSE'
access_token = '361530585-wd0bxaVjDlyBhnsaVAiTmVwbzoyMVmYLa3TtORVB'
access_token_secret = 'F0gseOFsJkJiSFMT7dnuCbVAbI5onNp8aaVs3YdzVJjdL'
```


```python
#API authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
#We are going to retrieve data from a list of target_users and by using a forloop we will be able to loop through 
##the last 100 tweets of each user and perform sentiment analysis. we will graph the compound

#part A: Store the sentiment analysis in a list and a dataframe

```


```python
#part B: Retrieving last 100 tweets of target_users and performing sentiment analysis on tweets. 

tweets=[]
target_users = ['@BBC','@CNN','@CBSNews','@FOXNews','@nytimes']

sentiment_analysis=[]
for x in range(5):
    
    for user in target_users:
        public_tweets = api.user_timeline(user, page=x)
    #     print(json.dumps(public_tweets,indent=4,sort_keys=True))
        for tweet in public_tweets:
            compound = analyzer.polarity_scores(tweet["text"])["compound"]
            pos = analyzer.polarity_scores(tweet["text"])["pos"]
            neu = analyzer.polarity_scores(tweet["text"])["neu"]
            neg = analyzer.polarity_scores(tweet["text"])["neg"]

#             tweets.append(tweet['text'])
            
            #store the sentiment analysis in a dataframe
            sentiment_analysis.append({'Compound': compound, 'Positive': pos, 'Negative':neg, 'Neutral':neu,'User': tweet['user']['screen_name'],
                                       'Date': tweet[ "created_at"],'Tweet': tweet['text']})

        
sentiments_pd = pd.DataFrame.from_dict(sentiment_analysis)
sentiments_pd = sentiments_pd[sentiments_pd.Date.notnull() & sentiments_pd.Tweet.notnull()]
sentiments_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweet</th>
      <th>User</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0000</td>
      <td>Sun Jan 14 20:15:03 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Britain is the only place in the world with a ...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.0790</td>
      <td>Sun Jan 14 20:00:09 +0000 2018</td>
      <td>0.142</td>
      <td>0.731</td>
      <td>0.128</td>
      <td>Long nights, snowshoes and a broken down boat....</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.2023</td>
      <td>Sun Jan 14 19:30:08 +0000 2018</td>
      <td>0.182</td>
      <td>0.677</td>
      <td>0.141</td>
      <td>Ten times pop culture romanticised sexual hara...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0772</td>
      <td>Sun Jan 14 19:00:07 +0000 2018</td>
      <td>0.188</td>
      <td>0.598</td>
      <td>0.214</td>
      <td>No sympathy from the camera operator at all. 😂...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.2960</td>
      <td>Sun Jan 14 18:33:04 +0000 2018</td>
      <td>0.000</td>
      <td>0.891</td>
      <td>0.109</td>
      <td>On the 65th anniversary of the Coronation, the...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-0.0772</td>
      <td>Sun Jan 14 18:00:06 +0000 2018</td>
      <td>0.098</td>
      <td>0.902</td>
      <td>0.000</td>
      <td>🚴🇨🇴 Could one of the toughest cycling races br...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.9423</td>
      <td>Sun Jan 14 17:30:08 +0000 2018</td>
      <td>0.000</td>
      <td>0.377</td>
      <td>0.623</td>
      <td>Rusty spotted cats are super rare, super small...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.2003</td>
      <td>Sun Jan 14 17:02:03 +0000 2018</td>
      <td>0.000</td>
      <td>0.905</td>
      <td>0.095</td>
      <td>Remember when Jay-Z had a legal showdown with ...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>8</th>
      <td>-0.4767</td>
      <td>Sun Jan 14 16:30:09 +0000 2018</td>
      <td>0.162</td>
      <td>0.838</td>
      <td>0.000</td>
      <td>🔍 @IanMcKellen stars as a retired Sherlock Hol...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.0000</td>
      <td>Sun Jan 14 16:00:06 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>In Greenland, you can find a shark that could ...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>10</th>
      <td>-0.1027</td>
      <td>Sun Jan 14 15:00:10 +0000 2018</td>
      <td>0.116</td>
      <td>0.789</td>
      <td>0.095</td>
      <td>A @NASA telescope has yielded important insigh...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.0000</td>
      <td>Sun Jan 14 14:00:04 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>While parts of the US &amp;amp; Canada felt as col...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.7264</td>
      <td>Sun Jan 14 13:26:03 +0000 2018</td>
      <td>0.000</td>
      <td>0.679</td>
      <td>0.321</td>
      <td>🎬 Thrillers, comedy and foreign drama.\n\n📺 @B...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.5093</td>
      <td>Sun Jan 14 13:03:04 +0000 2018</td>
      <td>0.000</td>
      <td>0.859</td>
      <td>0.141</td>
      <td>Nominations for the BBC Food and Farming Award...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>14</th>
      <td>-0.7650</td>
      <td>Sun Jan 14 12:30:07 +0000 2018</td>
      <td>0.306</td>
      <td>0.694</td>
      <td>0.000</td>
      <td>YouTube has decided to cut ties with vlogger L...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.0000</td>
      <td>Sun Jan 14 12:00:07 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Ever wondered how mayonnaise is made? \n\nTake...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>16</th>
      <td>-0.3612</td>
      <td>Sun Jan 14 11:30:09 +0000 2018</td>
      <td>0.217</td>
      <td>0.783</td>
      <td>0.000</td>
      <td>Snow has fallen in the Sahara desert. ❄️ https...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.8803</td>
      <td>Sun Jan 14 11:18:04 +0000 2018</td>
      <td>0.000</td>
      <td>0.662</td>
      <td>0.338</td>
      <td>RT @bbcmusic: Happy Birthday Dave Grohl! 🎁🎈✨\n...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.3612</td>
      <td>Sun Jan 14 11:03:03 +0000 2018</td>
      <td>0.000</td>
      <td>0.839</td>
      <td>0.161</td>
      <td>🐒❄️ Here's what the weather looked like around...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.8113</td>
      <td>Sun Jan 14 10:42:37 +0000 2018</td>
      <td>0.000</td>
      <td>0.599</td>
      <td>0.401</td>
      <td>RT @BBCRadio4: 🐦 Let this joyous birdsong ease...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-0.4939</td>
      <td>Mon Jan 15 04:01:51 +0000 2018</td>
      <td>0.211</td>
      <td>0.789</td>
      <td>0.000</td>
      <td>This is how people in Hawaii reacted to the mi...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.0000</td>
      <td>Mon Jan 15 03:53:02 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Oil tanker burning in the East China Sea sinks...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.6209</td>
      <td>Mon Jan 15 03:47:03 +0000 2018</td>
      <td>0.066</td>
      <td>0.701</td>
      <td>0.233</td>
      <td>As a citizen of Norway, I can tell you we're n...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>23</th>
      <td>-0.3400</td>
      <td>Mon Jan 15 03:41:06 +0000 2018</td>
      <td>0.136</td>
      <td>0.794</td>
      <td>0.070</td>
      <td>Former US Defense Secretary Chuck Hagel called...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.6369</td>
      <td>Mon Jan 15 03:31:21 +0000 2018</td>
      <td>0.000</td>
      <td>0.704</td>
      <td>0.296</td>
      <td>Here's a 2018 guide to Macau's best casinos ht...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>25</th>
      <td>-0.4019</td>
      <td>Mon Jan 15 03:30:05 +0000 2018</td>
      <td>0.231</td>
      <td>0.769</td>
      <td>0.000</td>
      <td>Pope Francis faces tensions on South America t...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.0000</td>
      <td>Mon Jan 15 03:19:41 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>The NFL playoff game between the Pittsburgh St...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>27</th>
      <td>-0.4404</td>
      <td>Mon Jan 15 03:06:51 +0000 2018</td>
      <td>0.139</td>
      <td>0.861</td>
      <td>0.000</td>
      <td>Republican Sen. Jeff Flake expected to deliver...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.7506</td>
      <td>Mon Jan 15 02:58:02 +0000 2018</td>
      <td>0.000</td>
      <td>0.766</td>
      <td>0.234</td>
      <td>Pope Francis' trip to South America this week ...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>29</th>
      <td>-0.5423</td>
      <td>Mon Jan 15 02:48:54 +0000 2018</td>
      <td>0.410</td>
      <td>0.432</td>
      <td>0.158</td>
      <td>What went wrong with Hawaii's false emergency ...</td>
      <td>CNN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>470</th>
      <td>0.0000</td>
      <td>Sun Jan 14 22:14:00 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>"You can either send money to Washington or yo...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>471</th>
      <td>0.0000</td>
      <td>Sun Jan 14 22:12:39 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Chelsea Manning confirms Senate bid, says 'Yup...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>472</th>
      <td>0.0000</td>
      <td>Sun Jan 14 22:12:14 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Drugged driver crashes car into second story o...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>473</th>
      <td>-0.4215</td>
      <td>Sun Jan 14 22:05:06 +0000 2018</td>
      <td>0.237</td>
      <td>0.763</td>
      <td>0.000</td>
      <td>.@BillClinton Denies Foundation Paid for Chels...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>474</th>
      <td>0.0000</td>
      <td>Sun Jan 14 22:04:08 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Ambassador James Jeffrey: "We are not well-pre...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>475</th>
      <td>-0.8625</td>
      <td>Sun Jan 14 21:59:04 +0000 2018</td>
      <td>0.490</td>
      <td>0.510</td>
      <td>0.000</td>
      <td>Hawaii's false missile threat: Worker 'feels t...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>476</th>
      <td>-0.3400</td>
      <td>Sun Jan 14 21:56:32 +0000 2018</td>
      <td>0.211</td>
      <td>0.789</td>
      <td>0.000</td>
      <td>Hawaii false alarm prompts plans for FCC inves...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>477</th>
      <td>-0.6908</td>
      <td>Sun Jan 14 21:56:04 +0000 2018</td>
      <td>0.251</td>
      <td>0.749</td>
      <td>0.000</td>
      <td>.@AlvedaCKing: "People were saying that Presid...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>478</th>
      <td>-0.1779</td>
      <td>Sun Jan 14 21:54:36 +0000 2018</td>
      <td>0.169</td>
      <td>0.693</td>
      <td>0.139</td>
      <td>Porn star Olivia Nova’s friend says she ‘wante...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>479</th>
      <td>0.0000</td>
      <td>Sun Jan 14 21:50:03 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>.@SecNielsen: "I don't recall [President #Trum...</td>
      <td>FoxNews</td>
    </tr>
    <tr>
      <th>480</th>
      <td>0.4588</td>
      <td>Sun Jan 14 15:00:18 +0000 2018</td>
      <td>0.133</td>
      <td>0.600</td>
      <td>0.267</td>
      <td>"I 100% support the fight for fair pay and I'm...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>481</th>
      <td>0.4215</td>
      <td>Sun Jan 14 14:46:02 +0000 2018</td>
      <td>0.000</td>
      <td>0.798</td>
      <td>0.202</td>
      <td>A new 3-D videomicroscope gives surgeons "Supe...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>482</th>
      <td>0.0000</td>
      <td>Sun Jan 14 14:33:01 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Opinion: "Hillary Clinton, the first woman who...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>483</th>
      <td>-0.7506</td>
      <td>Sun Jan 14 14:15:02 +0000 2018</td>
      <td>0.299</td>
      <td>0.701</td>
      <td>0.000</td>
      <td>"This system failed miserably and we need to s...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>484</th>
      <td>0.0000</td>
      <td>Sun Jan 14 14:00:13 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>An Iranian oil tanker that collided with anoth...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>485</th>
      <td>0.0000</td>
      <td>Sun Jan 14 13:49:03 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>RT @nytimesworld: In 2016, this is how @Pontif...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>486</th>
      <td>0.0000</td>
      <td>Sun Jan 14 13:36:04 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>"You can't look down to read the speech, you h...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>487</th>
      <td>-0.1027</td>
      <td>Sun Jan 14 13:15:07 +0000 2018</td>
      <td>0.167</td>
      <td>0.641</td>
      <td>0.192</td>
      <td>Opinion: Martin Luther King Jr.’s assassinatio...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>488</th>
      <td>0.0000</td>
      <td>Sun Jan 14 13:09:09 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Op-Ed Columnist: Is There Life After Liberalis...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>489</th>
      <td>-0.7351</td>
      <td>Sun Jan 14 13:00:22 +0000 2018</td>
      <td>0.267</td>
      <td>0.733</td>
      <td>0.000</td>
      <td>He was badly wounded during last summer’s atta...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>490</th>
      <td>0.2263</td>
      <td>Sun Jan 14 12:45:04 +0000 2018</td>
      <td>0.117</td>
      <td>0.769</td>
      <td>0.113</td>
      <td>The first time cutting season came around, Nic...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>491</th>
      <td>0.1027</td>
      <td>Sun Jan 14 12:30:06 +0000 2018</td>
      <td>0.094</td>
      <td>0.792</td>
      <td>0.114</td>
      <td>She even stopped using her full name — Ronna R...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>492</th>
      <td>0.0000</td>
      <td>Sun Jan 14 12:15:03 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>The Trump administration is set to shrink Bear...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>493</th>
      <td>-0.4939</td>
      <td>Sun Jan 14 12:00:10 +0000 2018</td>
      <td>0.176</td>
      <td>0.824</td>
      <td>0.000</td>
      <td>In 2017, extreme weather events caused a total...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>494</th>
      <td>0.0000</td>
      <td>Sun Jan 14 11:30:16 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>For decades the E train in NYC has been one of...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>495</th>
      <td>0.0000</td>
      <td>Sun Jan 14 11:19:31 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Vows: He Works With Divas, but Didn’t Marry On...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>496</th>
      <td>0.0000</td>
      <td>Sun Jan 14 11:16:13 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>A Greener, More Healthful Place to Work https:...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>497</th>
      <td>0.0000</td>
      <td>Sun Jan 14 11:15:07 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>A gym chain is banning CNN, Fox News and MSNBC...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>498</th>
      <td>0.0000</td>
      <td>Sun Jan 14 10:51:47 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>He's being called "frost boy." But the image o...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>499</th>
      <td>-0.1027</td>
      <td>Sun Jan 14 10:31:58 +0000 2018</td>
      <td>0.122</td>
      <td>0.778</td>
      <td>0.100</td>
      <td>RT @nytimesbooks: 11 new books recommended by ...</td>
      <td>nytimes</td>
    </tr>
  </tbody>
</table>
<p>500 rows × 7 columns</p>
</div>




```python
sentiments_pd.to_csv('500tweets.csv')
```


```python
compound_df = sentiments_pd[['Compound','Date','Tweet',"User"]].copy()
compound_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Tweet</th>
      <th>User</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0000</td>
      <td>Sun Jan 14 20:15:03 +0000 2018</td>
      <td>Britain is the only place in the world with a ...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.0790</td>
      <td>Sun Jan 14 20:00:09 +0000 2018</td>
      <td>Long nights, snowshoes and a broken down boat....</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.2023</td>
      <td>Sun Jan 14 19:30:08 +0000 2018</td>
      <td>Ten times pop culture romanticised sexual hara...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0772</td>
      <td>Sun Jan 14 19:00:07 +0000 2018</td>
      <td>No sympathy from the camera operator at all. 😂...</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.2960</td>
      <td>Sun Jan 14 18:33:04 +0000 2018</td>
      <td>On the 65th anniversary of the Coronation, the...</td>
      <td>BBC</td>
    </tr>
  </tbody>
</table>
</div>




```python
bbc_df = compound_df[['Compound','Date','Tweet',"User"]].copy()
bbc_df = bbc_df[bbc_df['User']=='BBC']
bbc_df

cbs_df = compound_df[['Compound','Date','Tweet',"User"]].copy()
cbs_df = cbs_df[cbs_df['User']=='CBSNews']
cbs_df

cnn_df = compound_df[['Compound','Date','Tweet',"User"]].copy()
cnn_df = cnn_df[cnn_df['User']=='CNN']
cnn_df

fox_df = compound_df[['Compound','Date','Tweet',"User"]].copy()
fox_df = fox_df[fox_df['User']== 'FoxNews']
fox_df

nytimes_df = compound_df[['Compound','Date','Tweet',"User"]].copy()
nytimes_df = nytimes_df[nytimes_df['User']== 'nytimes']
nytimes_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Tweet</th>
      <th>User</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>80</th>
      <td>-0.3400</td>
      <td>Mon Jan 15 02:22:26 +0000 2018</td>
      <td>‘I’m Not a Racist,’ Trump Says in Denying Vulg...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>81</th>
      <td>0.5574</td>
      <td>Mon Jan 15 02:09:54 +0000 2018</td>
      <td>Male sea turtles are disappearing from Austral...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0.0000</td>
      <td>Mon Jan 15 01:55:56 +0000 2018</td>
      <td>Breaking News: "I'm not a racist." President T...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>83</th>
      <td>-0.3818</td>
      <td>Mon Jan 15 01:49:14 +0000 2018</td>
      <td>Vikings Shock Saints on Last-Second Touchdown ...</td>
      <td>nytimes</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.0000</td>
      <td>Mon Jan 15 01:41:54 +0000 2018</td>
      <td>"You can't look down to read the speech, you h...</td>
      <td>nytimes</td>
    </tr>
  </tbody>
</table>
</div>




```python

bbc = (plt.scatter(np.arange(len(bbc_df["Compound"])), bbc_df["Compound"],c='turquoise', marker='o',alpha=0.6,edgecolors='black',label='BBC'))
cbs = (plt.scatter(np.arange(len(cbs_df["Compound"])), cbs_df["Compound"],c='green', marker='o',alpha=0.6,edgecolors='black',label='CBS'))
cnn = (plt.scatter(np.arange(len(cnn_df["Compound"])), cnn_df["Compound"],c='red', marker='o',alpha=0.6,edgecolors='black',label='CNN'))
fox = (plt.scatter(np.arange(len(fox_df["Compound"])), fox_df["Compound"],c='blue', marker='o',alpha=0.6,edgecolors='black',label='Fox News'))
nyt = (plt.scatter(np.arange(len(nytimes_df["Compound"])), nytimes_df["Compound"],c='yellow', marker='o',alpha=0.4,edgecolors='black', label='The New York Times'))
plt.legend(title='Media Sources',loc='center left', bbox_to_anchor=(1, 0.5))
plt.title('Sentiment Analysis of Media Tweets')
plt.xlabel('Tweets Ago')
plt.savefig('tweets.png')
plt.show()

```


![png](output_9_0.png)



```python
# media = ['@BBC','@CNN','@CBSNews','@FOXNews','@nytimes']
# x_axis = np.arange(len(media))
media = 'BBC'
averagemedia = bbc_df['Compound'].mean(axis=0)
plt.bar(media,averagemedia,color='r',alpha='0.6',align='edge')
plt.xticks(tick_locations,['BBC'])
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    ~/anaconda3/lib/python3.6/site-packages/matplotlib/colors.py in to_rgba(c, alpha)
        131     try:
    --> 132         rgba = _colors_full_map.cache[c, alpha]
        133     except (KeyError, TypeError):  # Not in cache, or unhashable.


    TypeError: unhashable type: 'numpy.ndarray'

    
    During handling of the above exception, another exception occurred:


    TypeError                                 Traceback (most recent call last)

    <ipython-input-99-817e609ce85a> in <module>()
          3 media = 'BBC'
          4 averagemedia = bbc_df['Compound'].mean(axis=0)
    ----> 5 plt.bar(media,averagemedia,color='r',alpha='0.6',align='edge')
          6 plt.xticks(tick_locations,['BBC'])


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/pyplot.py in bar(*args, **kwargs)
       2625                       mplDeprecation)
       2626     try:
    -> 2627         ret = ax.bar(*args, **kwargs)
       2628     finally:
       2629         ax._hold = washold


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/__init__.py in inner(ax, *args, **kwargs)
       1708                     warnings.warn(msg % (label_namer, func.__name__),
       1709                                   RuntimeWarning, stacklevel=2)
    -> 1710             return func(ax, *args, **kwargs)
       1711         pre_doc = inner.__doc__
       1712         if pre_doc is None:


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/axes/_axes.py in bar(self, *args, **kwargs)
       2148                 label='_nolegend_',
       2149                 )
    -> 2150             r.update(kwargs)
       2151             r.get_path()._interpolation_steps = 100
       2152             if orientation == 'vertical':


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/artist.py in update(self, props)
        845         try:
        846             ret = [_update_property(self, k, v)
    --> 847                    for k, v in props.items()]
        848         finally:
        849             self.eventson = store


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/artist.py in <listcomp>(.0)
        845         try:
        846             ret = [_update_property(self, k, v)
    --> 847                    for k, v in props.items()]
        848         finally:
        849             self.eventson = store


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/artist.py in _update_property(self, k, v)
        839                 if not callable(func):
        840                     raise AttributeError('Unknown property %s' % k)
    --> 841                 return func(v)
        842 
        843         store = self.eventson


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/patches.py in set_alpha(self, alpha)
        364                 raise TypeError('alpha must be a float or None')
        365         artist.Artist.set_alpha(self, alpha)
    --> 366         self._set_facecolor(self._original_facecolor)
        367         self._set_edgecolor(self._original_edgecolor)
        368         # stale is already True


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/patches.py in _set_facecolor(self, color)
        322             color = mpl.rcParams['patch.facecolor']
        323         alpha = self._alpha if self._fill else 0
    --> 324         self._facecolor = colors.to_rgba(color, alpha)
        325         self.stale = True
        326 


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/colors.py in to_rgba(c, alpha)
        132         rgba = _colors_full_map.cache[c, alpha]
        133     except (KeyError, TypeError):  # Not in cache, or unhashable.
    --> 134         rgba = _to_rgba_no_colorcycle(c, alpha)
        135         try:
        136             _colors_full_map.cache[c, alpha] = rgba


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/colors.py in _to_rgba_no_colorcycle(c, alpha)
        192     if alpha is not None:
        193         c = c[:3] + (alpha,)
    --> 194     if any(elem < 0 or elem > 1 for elem in c):
        195         raise ValueError("RGBA values should be within 0-1 range")
        196     return c


    ~/anaconda3/lib/python3.6/site-packages/matplotlib/colors.py in <genexpr>(.0)
        192     if alpha is not None:
        193         c = c[:3] + (alpha,)
    --> 194     if any(elem < 0 or elem > 1 for elem in c):
        195         raise ValueError("RGBA values should be within 0-1 range")
        196     return c


    TypeError: '<' not supported between instances of 'str' and 'int'



```python
bbc_df['Compound'].mean(axis=0)
```




    0.13103699999999996


